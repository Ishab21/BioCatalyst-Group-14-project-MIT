import torch 
import random 
from transformers import BertTokenizer, BertModel
from sklearn.metrics.pairwise import cosine_similarity 


random_seed = 42
random.seed(random_seed)

torch.manual_seed(random_seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(random_seed)

tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')

text = "if you're living with moderate to severe plaras or active psoriatic arthritis symptoms can sometimes hold you back but now they're skyzzy so you can be Allin with clear [Music] skin with Sky rzy you can show up with 90???% clear skin and if you have sertic arthritis sky rzy can help you move with less joint pain stiffness swelling and fatigue skyzzy is just four doses a year after two starter doses serious allergic reactions and an increased risk of infections or a lower ability to fight reactions and an increased risk of infections or a lower ability to fight them may occur tell your doctor if you have an infection or symptoms had a vaccine or plann to thanks to Sky rzy theres nothing like clear skin and better movement and that means everything Nows the Time ask your doctor about sky rzy learn how Abby could help you save"
#loopn through transcipts in dataloader

encoding = tokenizer.batch_encode_plus( [text], 
                                       padding = True, 
                                       truncation=True,
                                       return_tensors = 'pt',
                                       add_special_token = True
)

input_ids = encoding['input_ids']
print(input_ids)
attention_mask = encoding['attention_mask'] 
print(attention_mask)

with torch.no_grad():
    outputs = model(input_ids, attention_mask=attention_mask)
    word_embeddings = outputs.last_hidden_state

print(word_embeddings.shape)

# Decode the token IDs back to text
decoded_text = tokenizer.decode(input_ids[0], skip_special_tokens=True)
# Tokenize the text again for reference
tokenized_text = tokenizer.tokenize(decoded_text)
# Encode the text
encoded_text = tokenizer.encode(text, return_tensors='pt')

sentence_embedding = word_embeddings.mean(dim=1)
print(sentence_embedding)

#Once we figure out how to loop through all of the text we can use cosine similarity
example_text = "if you're living with dry AMD you may be at risk for developing Geographic atrophy or ga ga can be unpredictable and progress rapidly leading to irreversible vision loss now there's something you can do to slow it down get it going slower ask your doctor about eyes survey I survey it's G going slower iserve is an eye injection don't take it if you have an infection or active swelling in or around your eye eyes can cause eye infection retinal detachment or increased risk of wet AMD iserve May temporarily increase eye pressure do not driver or use Machinery until Vision has recovered after an eye injection or exam iserve is proven to slow GA progression which may help preserve Vision longer I going so shift gears and get going don't delay ask your doctor about eyes survey"
example_encoding = tokenizer.batch_encode_plus(
    [example_text],
    padding=True,
    truncation=True,
    return_tensors='pt',
    add_special_tokens=True
)
example_input_ids = example_encoding['input_ids']
example_attention_mask = example_encoding['attention_mask']

# Generate embeddings for the example sentence
with torch.no_grad():
    example_outputs = model(example_input_ids, attention_mask=example_attention_mask)
    example_sentence_embedding = example_outputs.last_hidden_state.mean(dim=1)

# Compute cosine similarity between the original sentence embedding and the example sentence embedding
similarity_score = cosine_similarity(sentence_embedding, example_sentence_embedding)
print(similarity_score)


