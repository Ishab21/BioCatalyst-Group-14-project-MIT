import json
import pandas as pd
import re

def load_multiple_json_objects(json_file):
    data = []
    with open(json_file, 'r') as file:
        content = file.read()

    # Add commas between objects and wrap in an array
    content = content.replace('}{', '},{')
    content = f'[{content}]'

    # Load the JSON data
    data = json.loads(content)
    return data

def extract_brand_and_year(video_title):
    """
    Extracts brand name (everything before the word 'Commercial') and year (within parentheses) from the video title.
    """
    # Use regex to find the brand (everything before 'Commercial') and the year (within parentheses)
    brand_match = re.search(r'^(.*?)\sCommercial', video_title, re.IGNORECASE)
    year_match = re.search(r'\((\d{4})\)', video_title)
    
    brand = brand_match.group(1).strip() if brand_match else None
    year = year_match.group(1) if year_match else None
    
    return brand, year

def create_dataframe(json_file):
    """
    Iterates through the JSON file and creates a DataFrame with video title, brand name, and year.
    """
    data = load_multiple_json_objects(json_file)
    
    # List to store rows for the DataFrame
    rows = []
    
    # Iterate through each video record in the JSON data
    for entry in data:
        video_title = entry.get('video_title', '')
        
        # Extract brand and year
        brand, year = extract_brand_and_year(video_title)
        
        # Append row with video title, brand, and year
        rows.append({
            'video_title': video_title,
            'brand': brand,
            'year': year
        })
    
    # Create DataFrame
    df = pd.DataFrame(rows)
    
    return df

json_file = "C:\\Users\\16465\\Downloads\\transcripts.json"  
df = create_dataframe(json_file)
print(df)

df.to_csv("commericals_output.csv", index=False)