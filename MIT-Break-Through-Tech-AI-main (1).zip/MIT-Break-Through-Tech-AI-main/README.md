### Youtube Scraper Instructions ###

1. Clone this repo into your favorite IDE with basic Python functionality
2. Run ```cd youtube_scrape```
3. Run ```export YTB_API_KEY=API_KEY_SENT_ON_DISCORD```
4. Run ```python ytb_scraper.py --channel_name CHANNEL_NAME --results_dir DIR_PATH --max_videos NUM_VIDS```
