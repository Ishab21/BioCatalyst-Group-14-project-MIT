import json
import pandas as pandas
import re
from youtube_transcript_api import YouTubeTranscriptApi

def extract_video_id(youtube_url):
   
    video_id_match = re.search(r"v=([^&]+)", youtube_url)
    if video_id_match:
        return video_id_match.group(1)
    raise ValueError("Invalid YouTube URL. Cannot extract video ID.")

def fetch_transcript(video_id):
   
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id, languages=["en"])
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

    transcript_text = "\n".join([entry['text'] for entry in transcript])
    return transcript_text

# Given YouTube URL
video_url = "https://www.youtube.com/watch?v=bu2CaHLkAhI"

video_id = extract_video_id(video_url)

transcript = fetch_transcript(video_id)

if transcript:
    print("--- Transcript ---\n")
    print(transcript)
else:
    print("Transcript could not be retrieved.")